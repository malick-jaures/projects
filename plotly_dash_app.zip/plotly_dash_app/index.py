import dash_core_components as dcc
import dash_html_components as html
import dash_bootstrap_components as dbc
from dash.dependencies import Input, Output, State
from app import app, server, session_id

import pandas as pd

from components import get_navbar, get_sidebar, parse_query_params, session_id

from views import dash, loans, channels


### Function to get Home for each session
def get_page_layout(session_id):
     
    return html.Div(
        [
            dcc.Location(id="url", refresh=False),
            html.Div(session_id, id='session-id', style={'display': 'none'}),
            dbc.Row(dbc.Col(get_navbar())),
            dbc.Row([
                dbc.Col(get_sidebar(), width={"size": 2,}, className="box"),
                dbc.Col(
                    html.Div(id="page-content"),
                    width={"size": 10,}, className="box"
                ), 
            ], 
                no_gutters=False,
            )
        ],

        className="container-fluid",
    )

app.layout = get_page_layout(session_id)


## For routing
@app.callback(
    Output("page-content", "children"),
    [Input("url", "pathname")],
    [State("url", "search")],
)
def render_page_content(pathname, search):
    ## Set page-content based on url
    if pathname in ["/", "/dash"]:
        return dash.layout
    elif pathname == "/loans":
        return loans.layout
    elif pathname == "/channels":
        return channels.layout
            
    # If the user tries to reach a different page, return a 404 message
    return dbc.Jumbotron(
        [
            html.H1("404: Not found", className="text-danger"),
            html.Hr(),
            html.P(f"The pathname {pathname} was not recognised..."),
        ]
    )

########################################################################################
@app.callback(
    [
        Output("dash", "active"), 
        Output("loans", "active"),
        Output("channels", "active"),
    ],
    [Input("url", "pathname")],
)
def toggle_active_links(pathname):
    return pathname == "/dash", pathname == "/loans", pathname == "/channels"



#########################################################################################################
if __name__ == "__main__":
    app.server.run(debug=True)