# from .config import CACHE_CONFIG, TIMEOUT
# from .app import cache1
