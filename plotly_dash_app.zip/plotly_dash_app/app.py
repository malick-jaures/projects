import dash
import dash_bootstrap_components as dbc
from flask import Flask, send_from_directory
from flask_caching import Cache
import os


## To assign session Id
import uuid

## get session ID
def get_session_id():
    return str(uuid.uuid4())
session_id = get_session_id()


# to deploy
server = Flask("My app")
app = dash.Dash(
    __name__,
    external_stylesheets=[dbc.themes.BOOTSTRAP], 
    server=server,
    meta_tags=[
        {
            'charset': 'utf-8',
        },
        {
            'name': 'My dashboard',
            'content': 'width=device-width, initial-scale=1, shrink-to-fit=no'
        }
    ]
)

app.title = "My dashboard"

#################################################################################################
app.config.suppress_callback_exceptions = True 
# app.css.config.serve_locally = True
# app.scripts.config.serve_locally = True

# config
server.config.update(
    SECRET_KEY=os.urandom(15),
)

############################ Cache and Session settings #####################################
TIMEOUT = 3600*6 ## In seconds

CACHE_CONFIG = {
    'CACHE_TYPE': 'filesystem',
    'CACHE_DIR': 'cache-directory',
    'CACHE_THRESHOLD': 200
}
cache1 = Cache()
cache1.init_app(app.server, config=CACHE_CONFIG)


