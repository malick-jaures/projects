
########################### Bar and Scatter config settings #######################################
BAR_PLOT_CONFIG = {
    "displaylogo": False,
    "displayModeBar": "hover",
    "modeBarButtonsToRemove": [
    	"zoom2d", "pan2d", "select2d", "lasso2d", "zoomIn2d", "zoomOut2d", "autoScale2d", "toggleSpikelines"
    ],
    # "toImageButtonOptions":{"width": None, "height": None,"format":["png, jpeg"]},
}

PIE_PLOT_CONFIG = {
    "displaylogo": False,
} 
########################### Rename some df indexes #######################################
GENDER_MAPPING = {'M': 'Male', 'F':'Female'}

SBU_MAPPING = {'R': 'Retail', 'C':'Corporate'}
