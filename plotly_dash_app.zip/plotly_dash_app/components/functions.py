from datetime import datetime as dt
from datetime import date, timedelta	
import time
import gc

import warnings
warnings.filterwarnings("ignore")
## To assign session Id
import uuid

import numpy as np
import pandas as pd
# from layouts import *

from components import *

## Set up session params to enhance performance
from app import cache1, TIMEOUT, session_id
## To handle the parameters by url
def parse_query_params(s):
    s = s.lstrip("?")
    return dict(pair.split("=") for pair in s.split("&"))

####################################################################################################
################################## Some useful functions ############################################
#####################################################################################################
def get_percentage_label(y):

    labels= []
    
    for i in y:
        labels += [str(i)+"%"]
        
    return labels


def format_big_number(d):
    dd = d.astype(str)
    for i in range(d.shape[0]):
        dd[i] = "{:,.0f}".format(d[i])
    
    return dd

    
def add_image_file_name_to_config(d1, d2):
    d = d1.copy()
    d["toImageButtonOptions"] = d2
    return d


#####################################################################################################
################################## Overview Page Content Functions###################################
#####################################################################################################
@cache1.memoize(timeout=TIMEOUT)
def get_data(session_id, cust_type='ALL'):

    data = pd.read_csv(f"/home/ebiele/workspace/dashboard/dashboard_apps/plotly_dash_app/data/NGGG1.csv")
    data["SBU"] = "R"
    data["SBU"] = np.where(data.Gender == "C", "C", data["SBU"])

    if cust_type == 'ALL':
        return data
    else:
        return data[data.SBU == cust_type]
