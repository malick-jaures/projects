from .header import get_navbar, get_sidebar
# from .my_functions import *
from .functions import * 