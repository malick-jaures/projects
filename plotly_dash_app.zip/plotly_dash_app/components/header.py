import dash_html_components as html
import dash_core_components as dcc
import dash_bootstrap_components as dbc


# IMBANK_LOGO = "https://www.imbank.com/rwanda/wp-content/themes/imtheme/images/im-logo.png"
IMBANK_LOGO = "img/im-logo.png"


def get_sidebar():
    sidebar = dbc.NavbarBrand(
        [
            dbc.NavLink("Overview",id="dash", href="/dash", className=""),
            dbc.NavLink("Loans", id="loans", href="/loans", className=""),
            dbc.NavLink("Channels",id="channels", href="/channels", className=""),
        ],
        id="sideNavBar",
        className="sidebar navbar-expand-lg navbar-light bg-light ",
        style={
            "list-style-type":"none",
            "overflow": "hidden",
            "position": "absolute",
            "top": "5px",
            "overflow-y": "scroll",
            "min-height": "100vh",
        }
    )
    return sidebar


def get_navbar(login=True):
    if login:
        navbar = dbc.Navbar(
            [
                html.A(
                    # Use row and col to control vertical alignment of logo / brand
                    dbc.Row(
                        [
                            dbc.Col(html.Img(src=IMBANK_LOGO, height="50px")),
        #                     dbc.Col(dbc.NavbarBrand("Navbar", className="ml-2")),
                        ],
                        align="center",
                        no_gutters=True,
                    ),
                    # href="https://www.imbank.com/rwanda/",
                    href="#",
                ),
                html.Div(id='user-name', className='link'),
                html.Div(id='logout', className='link', style={"margin":"0px 0px 0px 70%",}),
        #         dbc.NavbarToggler(id="navbar-toggler"),
        #         dbc.Collapse(search_bar, id="navbar-collapse", navbar=True),
            ],
            color="dark",
            dark=False,
            className="navbar navbar-expand navbar-dark flex-column flex-md-row bd-navbar",
            # style={
            #     "overflow": "hidden",
            #     "position": "fixed",
            # }
        )
        return navbar
    else:
        navbar = dbc.Navbar(
            [
                html.A(
                    # Use row and col to control vertical alignment of logo / brand
                    dbc.Row(
                        [
                            dbc.Col(html.Img(src=IMBANK_LOGO, height="50px")),
                        ],
                        align="center",
                        no_gutters=True,
                    ),
                    href="#",
                ),
            ],
            color="dark",
            dark=False,
            className="navbar navbar-expand navbar-dark flex-column flex-md-row bd-navbar",
        )
        return navbar

