import dash_core_components as dcc
import dash_html_components as html
import dash_bootstrap_components as dbc
# import dash_table
from dash.dependencies import Input, Output, State
import plotly.graph_objs as go
from plotly import tools

import warnings
warnings.filterwarnings("ignore")

import numpy as np

from app import app, session_id
from components import *
from config import *
 
#############################################################################################
######################     layout      ######################################################
#############################################################################################

layout = html.Div(
	[	
		html.H2("General Overview", style={"color":"DarkRed", "margin":"15px 0 0 0"}, id="general_overview"),
		html.Hr(),
		dbc.Row([
			dbc.Col([
				dcc.RadioItems(
					id= "select-cust_type",
					options=[
					    {'label': 'ALL', 'value': 'ALL'},
					    {'label': 'RETAIL', 'value': 'R'},
					    {'label': 'CORPORATE', 'value': 'C'},
					],
					value='ALL',
					labelStyle={'display': 'inline-block', 'margin':'10px 10px 10px 10px', 'font-size':20, 'font-style': 'italic'}
				),
			]),
		]),
		html.Div([
			html.Div(id="overview_info"),
			dcc.Interval(id="update-overview_info", interval=1000*60*60*2, n_intervals=0),
		]),
		html.Div([
			html.Div(id="overview_graph"),
			dcc.Interval(id="update-overview_graph", interval=1000*60*60*2, n_intervals=0),
		]),
	],
)

#############################################################################################
###################### layout callback ######################################################
#############################################################################################
@app.callback(
	
	Output("overview_info","children"),
	[
		Input("update-overview_info", "n_intervals"),
		Input("select-cust_type", "value"),
	]
)
def update_overview_info(n, cust_type):

	data= get_data(session_id, cust_type)

	output = None

	if cust_type == "C":
		output = html.Div([
			dbc.CardDeck(
				[
					dbc.Card(
						[
							html.H2("{}".format(data.shape[0] or "File doesn't exit")),
							html.H6("Total number of customers"),
						],
						body=True,
						style={"align": "center", "justify": "center", }
					),
					dbc.CardDeck([]),
					dbc.CardDeck([]),
				],
			)
		])

	else:
		output =  html.Div([
			dbc.CardDeck(
				[
					dbc.Card(
						[
							html.H2("{}".format(data.shape[0] or "File doesn't exit")),
							html.H6("Total number of customers"),
						],
						body=True,
						style={"align":"center", "justify":"center",}
					),
					dbc.Card(
						[
							html.H2("{:,.0f}".format(data[data["Gender"]=="F"].shape[0]), style={"color":"pink"}),
							html.H6("Female"),
						],
						body=True,
					),
					dbc.Card(
						[
							html.H2("{:,.0f}".format(data[data["Gender"]=="M"].shape[0]), style={"color":"blue"}),
							html.H6("Male"),
						],
						body=True,
					),
				],
			)
		])

	return output

#################################################################################
@app.callback(
	Output("overview_graph","children"),
	[
		Input("update-overview_graph", "n_intervals"),
		Input("select-cust_type", "value"),
	]
)
def update_overview_graph(n, cust_type):

	data= get_data(session_id, cust_type)

	colors_sbu=['Tomato','SeaGreen', 'RebeccaPurple']
	colors_gender=['gold', 'mediumturquoise', 'darkorange']

	customer_sbu = data.groupby("SBU").Client_No.count()

	customer_gender = data[data.SBU == "R"].groupby("Gender").Client_No.count()

	customer_per_branch= data.groupby("branch").Client_No.count()

	if cust_type == 'ALL':
		pieplot_output= dbc.CardGroup(
			[
	            dbc.Card(
	                [
	      				html.Div([
						        dcc.Graph(
							    figure=go.Figure(
							        data=[
							            go.Pie(
							            	labels=customer_sbu.rename(index=SBU_MAPPING).index, 
							            	values=customer_sbu,
							            	hole=0.3,	
							            	marker=go.pie.Marker(
							            		colors=colors_sbu, 
							            		# line=dict(color='#000000', width=1),
						            		),	
						            		# hoverinfo='label+value',
							            ),
							        ],
							        layout=go.Layout(
							            title="Customer per Strategy Business Unit (SBU)",
							            showlegend=True,
							            legend=go.layout.Legend(
							                x=0,
							                y=1.0
							            ),
							            margin=go.layout.Margin(l=5, r=5, t=30, b=5),

									),
							        
								    # displaylogo=False,
							    ),
							    style={'height': 300, "top":30},
							    id="pie-cart_1",
							    config= add_image_file_name_to_config(PIE_PLOT_CONFIG, {"filename": "{}".format( "Customer per Strategy Business Unit (SBU)" )}),
							)
	                    ]),
	                ],
	                body=True,
	                style={"padding":"5px 5px 5px 5px", },
	            ),
			],
		)

	elif cust_type == "R":
		pieplot_output= dbc.CardGroup(
			[
	            dbc.Card(
	                [
	                    html.Div([
						        dcc.Graph(
							    figure=go.Figure(
							        data=[
							            go.Pie(
							            	labels=customer_gender.rename(index=GENDER_MAPPING).index, 
							            	values=customer_gender,	
							            	hole=0.3,
							            	marker=go.pie.Marker(
							            		colors=colors_gender, 
						            		),						            		
							            ),
							        ],
							        layout=go.Layout(
							            title="Retail Customers Gender",
							            showlegend=True,
							            legend=go.layout.Legend(
							                x=0,
							                y=1.0
							            ),
							            margin=go.layout.Margin(l=5, r=5, t=30, b=5),
							            							            				                    	
							        )
							    ),
							    style={'height': 300, "top":30},
							    id="cart_2",
							    config= add_image_file_name_to_config(PIE_PLOT_CONFIG, {"filename": "{}".format( "Retail data Gender" )}),
							)
	                    ]),
	                ],
	                body=True,
	            ),
			],
		)

	else:
		pieplot_output= dbc.CardGroup([])


	##############################################################
	barplot_output= dbc.CardGroup([
		dbc.Card(
            [
                html.Div([
                	dcc.Graph(
					    figure=go.Figure(
					        data=[
					            go.Bar(
					                x=customer_per_branch.index,
					                y=customer_per_branch,
					                name='Customer per Branch',
					                text=get_percentage_label((customer_per_branch/customer_per_branch.sum()*100).round(2)),
        							textposition='auto',
					                marker=go.bar.Marker(
					                    color="green"
					                )
					            ),
					        ],
					        layout=go.Layout(
					            # showlegend=True,
					            legend=go.layout.Legend(
					                x=0.9,
					                y=1.0,
					                xanchor="center",
									yanchor="top",
					            ),
					            margin=go.layout.Margin(l=40, r=0, t=40, b=30),
					            title=go.layout.Title(
									text="Customer per Branch",
								# 	xref="paper",
								# 	x=0
								),
								xaxis=go.layout.XAxis(
									title=go.layout.xaxis.Title(
										text="Branch Name",
									)
								),
								yaxis=go.layout.YAxis(
									title=go.layout.yaxis.Title(
										text="Number of Customers",
									)
								)
					        )
					    ),
					    id='my-graph_1',
					    config= add_image_file_name_to_config(BAR_PLOT_CONFIG, {"filename": "{}".format( "Customer per Branch" )}),
					),
                	], 
                	id="barplot",
                ),
            ],
            body=True,
            style={"padding":"15px 15px 15px 15px",}
        ),
	])


	##########################################################################
	output =  html.Div([
		pieplot_output,
		barplot_output,

	])

	return output

