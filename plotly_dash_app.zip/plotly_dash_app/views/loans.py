import dash_core_components as dcc
import dash_html_components as html
import dash_bootstrap_components as dbc
# import dash_table
from dash.dependencies import Input, Output, State
import plotly.graph_objs as go
from plotly import tools

import warnings
warnings.filterwarnings("ignore")

"""
You can do the same as dash.py file
"""
layout = html.Div([

	html.H1("Loans"),

])