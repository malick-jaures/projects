

1. Open the command prompt in the unzipped folder

2. Run this command in command prompt
>> pip install -r requirements.txt

3. Run this to start the server 
>> python index.py

4. Copy and paste this in a bowser to view the application 
>> http://127.0.0.1:5000/